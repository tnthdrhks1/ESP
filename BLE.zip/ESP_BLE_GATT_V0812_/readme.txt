ESP32의 BLE를 GATT 방식으로 연결하는 코드
SERVER역할
해석을 잘 못하였음.

Recive, Send 부분이 어디인줄은 알겠는데 값을 처리하는 법을 모르겠음.

Rpi와 연결시 이유없이 끊길때가 있음.

배열처리를 못하겠음 실력부족

> 좀더편한? BTserial로 하려고함


RPI_ESP_GATT_CLIENT 폴더의 파일과 짝을 이룸.