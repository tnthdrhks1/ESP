GATT CLIENT 방식

ESP와 연결

해석 어느정도 했음.

ESP_BLE_GATT_V0812_폴더의 파일과 짝을 이룸.